______________________________________________________________________________________________________________________

 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL
______________________________________________________________________________________________________________________

Thank you for downloading this Mod <3 
Become a Patron and get early acces COMPLETE SRP Traffic Layout -> https://www.patreon.com/2real_mods

- Get unreleased 2REAL mods FOR FREE only on Discord: https://discord.gg/2real-1039865965824970853 -





Install:
Drop the shuto_revival_project_beta_ptb folder in your Tracks folder
-> Program Files\Steam\steamapps\common\assettocorsa\content\tracks

Replace files if nescessary.

Thats it :)



IMPORTENT INFO FOR MULTIPLAYER:
If you want to play the map online and want to prevent checksum error, rename the modded 
track folder (ex.: shuto_revival_project_beta_ptb_2real) and then just download & install the map again without any mods. 

______________________________________________________________________________________________________________________

 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL | 2REAL
______________________________________________________________________________________________________________________